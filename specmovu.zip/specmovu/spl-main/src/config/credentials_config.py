"""
This file contains all the credentials used in the project
"""
# used for service RapidApi for LinkedIn Api
X_RAPID_API_KEY = "c7a26a1867mshab3dbfc2dad5fe2p1332a0jsn2e2fe8fdf0ae"
# used for service RapidApi for LinkedIn Api
X_RAPID_API_HOST = "fresh-linkedin-profile-data.p.rapidapi.com"
