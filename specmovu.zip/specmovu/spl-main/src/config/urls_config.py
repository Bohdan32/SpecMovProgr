"""
Module for storing urls for requests
"""
GET_PERSONAL_PROFILE = "https://fresh-linkedin-profile-data.p.rapidapi.com/get-linkedin-profile"
GET_PROFILES_PHOTO = "https://fresh-linkedin-profile-data.p.rapidapi.com/get-profile-posts"
