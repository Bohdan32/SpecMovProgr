from ui.menu.menu_facade import MenuFacade

if __name__ == '__main__':
    menuFacade = MenuFacade()
    menuFacade.start()
