shared package
==============

Submodules
----------

shared.color\_processor module
------------------------------

.. automodule:: shared.color_processor
   :members:
   :undoc-members:
   :show-inheritance:

shared.data\_processor module
-----------------------------

.. automodule:: shared.data_processor
   :members:
   :undoc-members:
   :show-inheritance:

shared.file\_processors module
------------------------------

.. automodule:: shared.file_processors
   :members:
   :undoc-members:
   :show-inheritance:

shared.json\_processor module
-----------------------------

.. automodule:: shared.json_processor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: shared
   :members:
   :undoc-members:
   :show-inheritance:
