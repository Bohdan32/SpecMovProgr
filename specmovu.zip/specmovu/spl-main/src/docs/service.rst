service package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   service.lab2
   service.lab3
   service.lab4
   service.lab5
   service.lab7
   service.lab8

Module contents
---------------

.. automodule:: service
   :members:
   :undoc-members:
   :show-inheritance:
