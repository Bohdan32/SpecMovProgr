service.lab2 package
====================

Submodules
----------

service.lab2.calculator\_service module
---------------------------------------

.. automodule:: service.lab2.calculator_service
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: service.lab2
   :members:
   :undoc-members:
   :show-inheritance:
