ui.menu.lab8 package
====================

Submodules
----------

ui.menu.lab8.diagrams\_menu module
----------------------------------

.. automodule:: ui.menu.lab8.diagrams_menu
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu.lab8
   :members:
   :undoc-members:
   :show-inheritance:
