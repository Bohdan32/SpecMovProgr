ui.menu.lab7 package
====================

Submodules
----------

ui.menu.lab7.user\_menu module
------------------------------

.. automodule:: ui.menu.lab7.user_menu
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu.lab7
   :members:
   :undoc-members:
   :show-inheritance:
