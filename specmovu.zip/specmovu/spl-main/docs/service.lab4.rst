service.lab4 package
====================

Submodules
----------

service.lab4.data\_processors module
------------------------------------

.. automodule:: service.lab4.data_processors
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: service.lab4
   :members:
   :undoc-members:
   :show-inheritance:
