ui.menu.lab4 package
====================

Submodules
----------

ui.menu.lab4.own\_ascii\_art\_generator module
----------------------------------------------

.. automodule:: ui.menu.lab4.own_ascii_art_generator
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu.lab4
   :members:
   :undoc-members:
   :show-inheritance:
