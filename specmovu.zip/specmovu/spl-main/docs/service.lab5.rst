service.lab5 package
====================

Submodules
----------

service.lab5.figures\_service module
------------------------------------

.. automodule:: service.lab5.figures_service
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: service.lab5
   :members:
   :undoc-members:
   :show-inheritance:
