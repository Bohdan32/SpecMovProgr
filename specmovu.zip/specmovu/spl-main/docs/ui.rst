ui package
==========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ui.menu

Submodules
----------

ui.menu\_builder module
-----------------------

.. automodule:: ui.menu_builder
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui
   :members:
   :undoc-members:
   :show-inheritance:
