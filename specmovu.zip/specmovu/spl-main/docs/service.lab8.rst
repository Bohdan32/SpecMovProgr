service.lab8 package
====================

Submodules
----------

service.lab8.diagrams\_service module
-------------------------------------

.. automodule:: service.lab8.diagrams_service
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: service.lab8
   :members:
   :undoc-members:
   :show-inheritance:
