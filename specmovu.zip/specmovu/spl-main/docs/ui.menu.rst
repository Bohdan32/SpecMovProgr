ui.menu package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ui.menu.lab2
   ui.menu.lab3
   ui.menu.lab4
   ui.menu.lab5
   ui.menu.lab7
   ui.menu.lab8

Submodules
----------

ui.menu.docs\_menu module
-------------------------

.. automodule:: ui.menu.docs_menu
   :members:
   :undoc-members:
   :show-inheritance:

ui.menu.menu\_facade module
---------------------------

.. automodule:: ui.menu.menu_facade
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu
   :members:
   :undoc-members:
   :show-inheritance:
