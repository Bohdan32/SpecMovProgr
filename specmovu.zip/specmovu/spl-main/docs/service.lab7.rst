service.lab7 package
====================

Submodules
----------

service.lab7.user\_service module
---------------------------------

.. automodule:: service.lab7.user_service
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: service.lab7
   :members:
   :undoc-members:
   :show-inheritance:
