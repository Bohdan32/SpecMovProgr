ui.menu.lab2 package
====================

Submodules
----------

ui.menu.lab2.calculator\_menu module
------------------------------------

.. automodule:: ui.menu.lab2.calculator_menu
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu.lab2
   :members:
   :undoc-members:
   :show-inheritance:
