ui.menu.lab5 package
====================

Submodules
----------

ui.menu.lab5.figures module
---------------------------

.. automodule:: ui.menu.lab5.figures
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ui.menu.lab5
   :members:
   :undoc-members:
   :show-inheritance:
